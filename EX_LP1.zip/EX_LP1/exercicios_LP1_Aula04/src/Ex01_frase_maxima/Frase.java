
/*
1. Escreva um programa que leia uma frase com no
máximo 20 caracteres. Caso o usuário informar
uma frase com mais de 20 caracteres, ele deve
entrar com uma nova frase. A leitura deve ser
realizada no método main.

*/
package Ex01_frase_maxima;

public class Frase {
        
    
    
    
}
