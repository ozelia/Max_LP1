/*
2. A partir do exercício anterior, crie um método que
receba a frase e retorna a quantidade de
caracteres da frase (contando com os espaços).

*/
package Ex02_qtd_caracter;

public class QtdChar_ComEspaco {
    
    public static void main(String[] args) {
       
        
        QtdCaracter frase = new  QtdCaracter();
        
       frase.tamanhoDaFrase();
       
    }
    
}
