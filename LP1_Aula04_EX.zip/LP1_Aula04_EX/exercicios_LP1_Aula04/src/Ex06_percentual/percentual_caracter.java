/*
 A partir do exercício 1, crie um método que
receba a frase e um caractere e retorne o
percentual da ocorrência deste caractere na frase.
 */
package Ex06_percentual;

public class percentual_caracter {   
   
    
    public static void main(String[] args) {
        
        Percentual frase = new Percentual();
        
        frase.percent_caracter();
        
        
    }
    
}
