/*A partir do exercício 1, crie um método que
receba a frase e um caractere e retorne a média
de letras das palavras que iniciam com o
caractere passado por parâmetro*/
package Ex05_media;

public class MediaPalavra {

    public static void main(String[] args) {
        
          Media_Letras frase = new Media_Letras();
        
         frase.calcularMedia();
         
    }
    
}
