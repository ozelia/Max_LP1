/*
3. A partir do exercício 1, crie um método que
receba a frase e retorna a quantidade de
caracteres da frase sem os espaços em branco.

*/
package Ex03_qtd_caracter;

import Ex02_qtd_caracter.QtdCaracter;

public class QtdChar_SemEspaco {

    public static void main(String[] args) {
        
         QtdCaracter frase = new QtdCaracter();
         frase.tamanhoSemEspaco();
           
        
    }
    
}
