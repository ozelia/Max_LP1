/*
4. A partir do exercício 1, crie um método que
receba a frase e retorne a quantidade de palavras
da frase.
*/
package Ex04_qtdPalavras;

public class QtdPalavras_frase {

    public static void main(String[] args) {
        
         QtdPalavras frase = new QtdPalavras();
         frase.qtdPalavras();
        
    }
    
}
